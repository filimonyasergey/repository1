package com.example.filimonov;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    Spinner spFilter;

    List<SystemModel> fullList;
    List<SystemModel> filteredList;
    SystemAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        spFilter = findViewById(R.id.spFilter);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        fullList = new ArrayList<>();

        // ====== Заполняем список систем ======
        fullList.add(new SystemModel(
                "Рулонные шторы",
                "Компактная система для современных интерьеров",
                R.drawable.roll,
                2500,
                "Шторы",
                "Полиэстер",
                "Квартира, офис, крупные окна",
                "Легкая установка, долговечность, защита от солнца"
        ));

        fullList.add(new SystemModel(
                "Рулонные День-Ночь",
                "Чередование прозрачных и плотных полос",
                R.drawable.daynight,
                2800,
                "Шторы",
                "Полиэстер",
                "Квартира, офис",
                "Регулировка освещенности, современный дизайн"
        ));

        fullList.add(new SystemModel(
                "Горизонтальные жалюзи",
                "Классическое решение для офисов и дома",
                R.drawable.horizontal,
                2200,
                "Жалюзи",
                "Алюминий",
                "Офис, квартира",
                "Легкая очистка, долговечность"
        ));

        fullList.add(new SystemModel(
                "Вертикальные жалюзи",
                "Идеальны для больших окон",
                R.drawable.verticall,
                2000,
                "Жалюзи",
                "Ткань / Полиэстер",
                "Крупные окна, офис, коммерческие помещения",
                "Легкая регулировка освещенности, современный дизайн"
        ));

        fullList.add(new SystemModel(
                "Алюминиевые жалюзи",
                "Прочные и устойчивые к влаге",
                R.drawable.aluminium,
                2300,
                "Жалюзи",
                "Алюминий",
                "Офис, кухня, ванная",
                "Не ржавеют, легко чистятся, долговечные"
        ));

        fullList.add(new SystemModel(
                "Деревянные жалюзи",
                "Премиальный вариант из натурального дерева",
                R.drawable.wood,
                3500,
                "Жалюзи",
                "Натуральное дерево",
                "Квартира, загородный дом, кабинет",
                "Эстетичный внешний вид, долговечность, защита от солнца"
        ));

        filteredList = new ArrayList<>(fullList);

        adapter = new SystemAdapter(filteredList, this);
        recyclerView.setAdapter(adapter);

        // ====== Фильтр ======
        String[] filters = {"Все", "Шторы", "Жалюзи"};
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, filters);
        spFilter.setAdapter(spinnerAdapter);

        spFilter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                filterList(filters[position]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });
    }

    private void filterList(String type) {
        filteredList.clear();
        if (type.equals("Все")) {
            filteredList.addAll(fullList);
        } else {
            for (SystemModel model : fullList) {
                if (model.getType().equals(type)) {
                    filteredList.add(model);
                }
            }
        }
        adapter.notifyDataSetChanged();
    }
}
