package com.example.filimonov;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SystemActivity extends AppCompatActivity {

    double pricePerMeter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_system);

        ImageView img = findViewById(R.id.imgBig);
        TextView tvName = findViewById(R.id.tvName);
        TextView tvDesc = findViewById(R.id.tvDesc);
        TextView tvMaterial = findViewById(R.id.tvMaterial);
        TextView tvUsage = findViewById(R.id.tvUsage);
        TextView tvFeatures = findViewById(R.id.tvFeatures);

        EditText etWidth = findViewById(R.id.etWidth);
        EditText etHeight = findViewById(R.id.etHeight);
        CheckBox cbAutomation = findViewById(R.id.cbAutomation);
        Button btnCalc = findViewById(R.id.btnCalc);
        TextView tvResult = findViewById(R.id.tvResult);

        Intent intent = getIntent();
        tvName.setText(intent.getStringExtra("name"));
        tvDesc.setText(intent.getStringExtra("desc"));
        img.setImageResource(intent.getIntExtra("image", 0));
        pricePerMeter = intent.getDoubleExtra("price", 0);

        tvMaterial.setText("Материал: " + intent.getStringExtra("material"));
        tvUsage.setText("Рекомендовано для: " + intent.getStringExtra("usage"));
        tvFeatures.setText("Особенности: " + intent.getStringExtra("features"));

        btnCalc.setOnClickListener(v -> {
            String wText = etWidth.getText().toString().trim();
            String hText = etHeight.getText().toString().trim();

            if (wText.isEmpty() || hText.isEmpty()) {
                Toast.makeText(this, "Введите ширину и высоту", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                double width = Double.parseDouble(wText);
                double height = Double.parseDouble(hText);
                double area = (width / 1000) * (height / 1000);
                double total = area * pricePerMeter;

                if (cbAutomation.isChecked()) total += 3000;

                tvResult.setText("Стоимость: " + Math.round(total) + " руб.");
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Неверный формат числа", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
