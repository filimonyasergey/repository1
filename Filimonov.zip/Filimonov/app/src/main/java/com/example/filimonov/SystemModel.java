package com.example.filimonov;

import java.io.Serializable;

public class SystemModel implements Serializable {
    private String name;
    private String description;
    private int imageRes;
    private double pricePerMeter;
    private String type;

    private String material;
    private String usage;
    private String features;

    public SystemModel(String name, String description, int imageRes, double pricePerMeter, String type,
                       String material, String usage, String features) {
        this.name = name;
        this.description = description;
        this.imageRes = imageRes;
        this.pricePerMeter = pricePerMeter;
        this.type = type;
        this.material = material;
        this.usage = usage;
        this.features = features;
    }

    // Геттеры
    public String getName() { return name; }
    public String getDescription() { return description; }
    public int getImageRes() { return imageRes; }
    public double getPricePerMeter() { return pricePerMeter; }
    public String getType() { return type; }
    public String getMaterial() { return material; }
    public String getUsage() { return usage; }
    public String getFeatures() { return features; }
}
