package com.example.filimonov;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class SystemAdapter extends RecyclerView.Adapter<SystemAdapter.ViewHolder> {

    private List<SystemModel> list;
    private Context context;

    public SystemAdapter(List<SystemModel> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_system, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        SystemModel model = list.get(position);

        holder.tvName.setText(model.getName());
        holder.tvShortDesc.setText("Цена от " + model.getPricePerMeter() + " руб/м²");
        holder.imgSystem.setImageResource(model.getImageRes());

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, SystemActivity.class);
            intent.putExtra("name", model.getName());
            intent.putExtra("desc", model.getDescription());
            intent.putExtra("image", model.getImageRes());
            intent.putExtra("price", model.getPricePerMeter());
            intent.putExtra("material", model.getMaterial());
            intent.putExtra("usage", model.getUsage());
            intent.putExtra("features", model.getFeatures());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() { return list.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgSystem;
        TextView tvName, tvShortDesc;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgSystem = itemView.findViewById(R.id.imgSystem);
            tvName = itemView.findViewById(R.id.tvName);
            tvShortDesc = itemView.findViewById(R.id.tvShortDesc);
        }
    }
}
