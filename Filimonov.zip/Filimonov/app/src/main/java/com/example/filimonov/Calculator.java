package com.example.filimonov;

public class Calculator {

    public static double calculate(
            double width,
            double height,
            String systemType,
            boolean automation,
            boolean installation) {

        double area = (width / 1000) * (height / 1000);
        double pricePerMeter = 0;

        switch (systemType) {
            case "Рулонные":
                pricePerMeter = 2500;
                break;
            case "Горизонтальные":
                pricePerMeter = 2200;
                break;
            case "Вертикальные":
                pricePerMeter = 2000;
                break;
            case "Римские":
                pricePerMeter = 3000;
                break;
        }

        double total = area * pricePerMeter;

        if (automation) total += 3000;
        if (installation) total += 1500;

        return total;
    }
}

